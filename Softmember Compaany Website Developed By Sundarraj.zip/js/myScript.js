$(document).ready(function(){
    $(".java").click(function(){
        $(".java2").toggle(500);
    });
});