<?php
	$conf = new MySqli("localhost","root","1650","softmember");
	
	if($conf->connect_error)
	{
		echo $conf->connect_error;
		die('Database Connection Error');
	}
	else
	{
		echo 'Database Connected';
	}