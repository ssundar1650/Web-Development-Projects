<?php
	error_reporting(E_PARSE | E_ERROR);
	include('conf.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8'/>
    <meta content='IE=edge' http-equiv='X-UA-Compatible'/>
    <meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
	<meta name="description" content="SoftMember Provides Computer Sales and Service, Desktop & Laptop Peripherals and Repairs for Software & Hardware Services in Aranthangi India.">
    <meta name="keywords" content="softmember,softmember aranthangi,computer service,laptop service,printer service,software installation,mssoft1650">    
    <meta name="author" content="MSSoft1650">
	<title>Welcome To SoftMember | SoftMember Provides Computer Sales and Service, Desktop & Laptop Peripherals and Repairs for Software & Hardware Services in Aranthangi India.</title>
	<link rel="icon" href="img/smlogo.png" type="image/png">
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="mycss/style.css" type="text/css">
	<link rel="stylesheet" href="css/slider.css">
	<link rel="stylesheet" href="css/animate.css">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="js/myScript.js"></script>
	<script type="text/javascript" src="js/date_time.js"></script>
	<script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
</head>
<body>
	<div class="row topnav fixed-top">
		<div class="col-md-12">
			<div class="row">
			<div class="container">
				<div class="col-md-12">
					<div class="time">
						<span id="date_time" class=""></span>
						<script type="text/javascript">window.onload = date_time('date_time');</script>
					</div>
					<div class="chat">
						<p class="text-right"><a href="https://api.whatsapp.com/send?phone=919159344508"><i class="fab fa-whatsapp"></i> Click To Whatsapp Live Chat</a></p>
					</div>
				</div>
			</div>
			</div>
		</div>
	</div>
	<div class="mainDiv">
	<div class="">
		<div class="container">
			<div class="headerLogo">
					<img src="img/softmember logo.jpg" width="240px" class="" height="80px" alt="softmember">
				
				<div class="menu">
					<ul>
						<li><a href="tel:+919159344508"><img src="img/call.jpg" width="28px" height="27px"></a></li>
						<li><a href="https://www.facebook.com/softmember"><img src="img/facebook.png"></a></li>
						<li><a href="tel:+919629904769"><img src="img/twitter.png"></a></li>
						<li><a href="https://plus.google.com/111518634223308237295"><img src="img/google.png"></a></li>
						<li><a href="https://api.whatsapp.com/send?phone=919159344508"><img src="img/whatsapp.png" width="30px" height="30px"></a></li>
					</ul>
				</div>
			</div>
		</div>
	<div class="header">
		<nav>
		<div class="toggle">
			<h4 class="menuItems">MENU</h4><i class="fas fa-bars java"></i>
		</div>
			<ul class="java2">
				<div class="container">
					<li class="firmenu"><a href="#"><i class="fas fa-home"></i> Home</a></li>
					<li><a href="#"><i class="fas fa-address-card"></i> Contacts</a></li>
					<li><a href="#"><i class="fas fa-user"></i> About Me</a></li>
				</div>
			</ul>
		</nav>
	</div>
	</div>

	
	<div class="">
	<div class="row">
	<div class="container">
		<div class="section">
				<div class="slider" slide-interval="6000">
					<div class="slide active">
						<div class="slide-img" img-src="img/show1.png"></div>
						<div class="substrate"></div>
						<div class="slide-text">
							
						</div>
					</div>
					<div class="slide">
						<div class="slide-img" img-src="img/show2.png"></div>
						<div class="substrate"></div>
						<div class="slide-text">
							
						</div>
					</div>
					<div class="slide">
						<div class="slide-img" img-src="img/show3.png"></div>
						<div class="substrate"></div>
						<div class="slide-text">
							
						</div>
					</div>
					<div class="slide">
						<div class="slide-img" img-src="img/show4.png"></div>
						<div class="substrate"></div>
						<div class="slide-text">
							
						</div>
					</div>
					<div class="slide-pre"></div>
					<div class="slide-next"></div>
				</div>
		 </div>
		</div>
		</div>
		</div>
		
		
	
	<div class="descriptionDiv">
		<div class="container">
			<div class="col-md-12">
				<h1 class="text-center wow bounceInLeft" data-wow-delay="0.3s">WELCOME TO SOFTMEMBER COMPANY</h1>
				
				<div class="textbox wow fadeInRight data-wow-delay="1.0s">
					<h4 class="text-center">We are happy to inform you that we have been providing our services to the IT industry for the past 5 years…</h4>
				</div>
				<br>
				<div class="textDescription">
					<p class="text-center wow fadeInLeft data-wow-delay="1.0s">SoftMember Company was established in the spring of 2013 as a computer hardware servicing and maintenance company. We have very quickly gained the reputation for being the company that meets commitments to its customers and also a company that consistently achieves service levels beyond our customers’ expectation.</p>
				</div>
			</div>
		</div>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h4 class="sertext"><i class="fas fa-cogs"></i> Services</h4><br>
					<div class="row">
						<div class="col-md-12 serBox">
							<div class="serDescri1 serDescri wow bounceInLeft data-wow-delay="0.5s">
								<div class="row">
									<div class="col-md-12">
										<img src="img/comp.png" width="180px" height="150px" align="left" class="imgs">
										
										<div class="subtitle">
										<h4 class=""><i class="fas fa-chevron-circle-right"></i> Computer Sales & Services</h4>
										<p align="justify">We undertake installation and trouble-shooting of all types of Desktop PCs, Notebooks and Laptops with competitive prices</p>
										</div>
									</div>
								</div>
							</div>
							<div class="serDescri2 serDescri wow bounceInRight data-wow-delay="1.0s">
								<div class="row">
									<div class="col-md-12">
										<img src="img/comp1.png" width="180px" height="150px" align="left" class="imgs">
										<div class="subtitle">
										<h4 class=""><i class="fas fa-chevron-circle-right"></i> Computer Peripherals</h4>
										<p align="justify">We take up installation and repairs of all type of printers and accessories</p>
										</div>
									</div>
								</div>
							</div>
							<div class="serDescri3 serDescri wow bounceInLeft data-wow-delay="1.5s">
								<div class="row">
									<div class="col-md-12">
										<div class="subtitle">
										<img src="img/comp2.png" width="180px" height="150px" align="left" class="imgs">
										<h4 class=""><i class="fas fa-chevron-circle-right"></i> Hardware & Networking</h4>
										<p align="justify">We upgrade Computer hardware & software,We offer On-Site Servicing of all types of Networking & CCTV solutions</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
			</div>
			
			<div class="col-md-6 wow fadeInRight data-wow-delay="1.5s">
				<h4 class="sertext"><i class="far fa-edit"></i> Services Request</h4>
				<br>
				<div class="col-md-12 form">
					<form action="index.php" method="POST">
						<input type="text" name="name" required class="ip ipname" placeholder="Enter Your Name : "/>
						<br>
						<input type="text" name="phnumber" required class="ip number" placeholder="Phone Number : "/>
						<br>
						<input type="text" name="mail" required class="ip mail" placeholder="Email Address : "/>
						<br>
						<div class="devices"><input name="ser" required type="radio" value="Computer"/> Computer <input required name="ser" type="radio" value="Laptop"/> Laptop <input name="ser" type="radio" value="Printer"/> Printer <input name="ser" type="radio" value="Others"/> Others </div>
						<input required type="text" name="msg" class="ip mail" placeholder="Enter Your Message : "/><br>
						<textarea required rows="5" cols="10" name="address" class="ip rform" placeholder="Enter Your Address : "></textarea>
						
						<br>
						
						<input type="submit" name="submit" placeholder="Submit" class="btn btn1 btn-danger">
					</form>
				</div>
			
			
			<?php
				if(isset($_POST['submit']))
				{
					$uname=$_POST['name'];
					$number=$_POST['phnumber'];
					$email=$_POST['mail'];
					$service=$_POST['ser'];
					$message=$_POST['msg'];
					$uaddress=$_POST['address'];
					
					if($uname!=""&&$number!=""&&$email!=""&&$service!=""&&$message!=""&&$uaddress!="")
					{
						$sql="INSERT INTO web(NAME,PHONE,EMAIL,SERVICES,MESSAGE,ADDRESS)VALUES('$uname','$number','$email','$service','$message','$uaddress')";
						if($conf->query($sql))
						{
							echo "<p class='text-right tgreen'>Process Successfully :)</p>";
						}
						else
						{
							echo "<p class='text-right tred'>Database Busy</p>";
						}
					}
					else
					{
						echo "<p class='text-right tred'>Database Error :(</p>";
					}
				}
				else
				{
					echo("");
				}
			
			?>
			</div>
		</div>
	</div>
	
	
	<div class="col-md-12 subFooters">
		<div class="row">
			<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="subFooter">
						<h4 class="page-header pagesubtitle">About Me</h4>
						<br>
						<p><b>SOFTMEMBER provides computers, laptops, scanners, printers, other peripherals and networking solutions. We are happy to inform you that we have been providing our services to the IT industry for the past 24 years of satisfied customer requirements for quality computer products and services.</b></p>
					</div>
				</div>
				
				<div class="col-md-4">
					<div class="subFooter">
						<h4 class="page-header pagesubtitle">Services</h4><br>
						
						<p><b><i class="fas fa-hand-point-right"></i> Computer Maintenance</b></p>
						<p><b><i class="fas fa-hand-point-right"></i> Desktop & Laptop Repairs</b></p>
						<p><b><i class="fas fa-hand-point-right"></i> Data Backup and Recovery</b></p>
						<p><b><i class="fas fa-hand-point-right"></i> Networks Maintenance</b></p>
						<p><b><i class="fas fa-hand-point-right"></i> Software & Driver Installation</b></p>
						
					</div>
				</div>
				
				<div class="col-md-4">
					<div class="subFooter">
						<h4 class="page-header pagesubtitle">Get in Touch</h4><br>
						<p><b>SoftMember<br>
						350,kottai 2
						sivankovil theru<br>
						aranthangi, Aranthangi
						Tamilnadu</b></p>
						
						<p><b><i class="fas fa-envelope"></i> softmember@gmail.com</b></p>
						<p><b><i class="fas fa-comment"></i> +918838879756</b></p>
						
						
						<script language="JavaScript">var fhsh = document.createElement('script');var fhs_id_h = "3303440";
fhsh.src = "//freehostedscripts.net/ocount.php?site="+fhs_id_h+"&name=Visits&a=1";
document.head.appendChild(fhsh);document.write("<span id='h_"+fhs_id_h+"'></span>");
</script>
<script language="JavaScript">var fhs = document.createElement('script');var fhs_id = "5563590";
var ref = (''+document.referrer+'');var pn =  window.location;var w_h = window.screen.width + " x " + window.screen.height;
fhs.src = "//freehostedscripts.net/ocounter.php?site="+fhs_id+"&e1=Online User&e2=Online Users&r="+ref+"&wh="+w_h+"&a=1&pn="+pn+"";
document.head.appendChild(fhs);document.write("<span id='o_"+fhs_id+"'></span>");
</script>

						
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer col-md-12">
		<div class="row">
			<div class="col-md-6">
				<p class="text-right"><a href="#" class="text-right"><i class="fas fa-copyright"></i> Copyright By : SoftMember Company</a></p>
			</div>
			<div class="col-md-6">
				<p class=""><a href="https://www.facebook.com/javacseofficial"><i class="fas fa-code"></i> Designed And Developed By : MSSoft1650</a></p></center>
			</div>
		</div>
	</div>
	
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="js/slider.js"></script>
    <script type="text/javascript">

  

</script>
</div>	
</body>
</html>