<?php
	include('conf.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome To MSSoft1650 | Software Development | Web Development | Logo Designing</title>
	<meta charset='utf-8'/>
	<meta content='IE=edge' http-equiv='X-UA-Compatible'/>
	<meta name="description" content="MSSoft1650 | No1 Software And Website & Logo Designing And Developing Company In Pudukkottai,Tamil Ndu,India">
	<meta name="keywords" content="MSSoft1650,mssoft1650,mssweb,software company,web development company,logo designing,javacse,web design,seo">
	<meta name="author" content="MSSoft1650">
	<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
	<link rel="icon" href="img/icon.png" type="png/icon">
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="mycss/style.css" type="text/css">
	<link rel="stylesheet" href="css/contacts.css" type="text/css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div id="main">
	<div class="mainDiv">
			<div class="nav">
				<div class="topDiv">
					<div class="callDiv">
						<a href="tel:+919629904769">Call Now : +919629904769</a><a href="mailto:mssoft1650@gmail.com"> | mssoft1650@gmail.com</a>
					</div>
					<ul align="" class="toplist">
						<li><a href="https://www.mssoft1650.blogspot.com">Blog</a></li>
						<li><a href="https://www.youtube.com/channel/UCTyxvgSc9FAHP0zJCWmVKQA"><i class="fab fa-youtube"></i></a></li>
						<li><a href="https://plus.google.com/101447433080714641119"><i class="fab fa-google-plus-g"></i></a></li>
						<li><a href="https://www.instagram.com/javacse/"><i class="fab fa-instagram"></i></a></li>
						<li><a href="https://www.twitter.com/mssoft1650"><i class="fab fa-twitter"></i></a></li>
						<li><a href="https://www.facebook.com/mssoft1650"><i class="fab fa-facebook-f"></i></a></li>
					</ul>
				</div>
				
				<header>
				<div class="container">
					<div class="mobMenu" id="mobMenu">
						<a href="" onclick="openSideMenu()"><i class="fas fa-bars"></i></a>
					</div>
					<div class="logoDiv">
						<img src="logo/mssoft1650.png" height="80px" width="270px">
					</div>
					
					<div class="menuDiv">
						<ul class="">
							<li><a href="Contacts,php" class="actives"><i class="fas fa-phone"></i> Contacts</a></li>
							<li><a href="About-Us.html" class="actives"><i class="fas fa-user"></i> About Me</a></li>
							<li><a href="Services.html" class="actives"><i class="fas fa-cog"></i> Services</a></li>
							<li><a href="index.html" class="activez"><i class="fas fa-home"></i> Home</a></li>
						</ul>
					</div>
					</div>
				</header>
				<div class="sideMenu" id="sideMenu">
					<a href="#" onclick="closeSideMenu()" class="closeBtn" style="margin-top:50px; color:#0061cd; font-weight:bold;">X Close</a>
						<center><img src="img/icon.png" width="50%" height="50%"></center>
					<ol class="">
						<li><a href="index.html" class=""><i class="fas fa-home"></i> Home</a></li>
						<li><a href="Services.html" class=""><i class="fas fa-cog"></i> Service</a></li>
						<li><a href="About-Us.html" class=""><i class="fas fa-user"></i> About Me</a></li>
						<li><a href="Contacts.html" class=""><i class="fas fa-phone"></i> Contacts</a></li>	
					</ol>
					<center>
						<br><h2 style="color:white; opacity:0.5;"><b>Follow On</b></h2>
					</center>
					
					<br><center><a href="https://www.facebook.com/javacseofficial" class="sfollow"><i class="fab fa-facebook-f"></i></a><a href="https://www.twitter.com/mssoft1650" class="sfollow"><i class="fab fa-twitter"></i></a><a href="https://www.instagram.com/javacse/" class="sfollow"><i class="fab fa-instagram"></i></a><a  class="sfollow" href="https://plus.google.com/101447433080714641119"><i class="fab fa-google-plus-g"></i></a></center>
				</div>
					
			</div>
			
			<div class="contactShowcase">
				<h6 class="aboutLetter" style="font-size:80px !important; font-weight:bold; opacity:1.0; color:#0061cd; padding-top:11%;"><center>Contact Us</center></h6>
			</div>
			<div class="shawdow"></div>
			<div class="">
				<div class="container">
					<div class="row conTopspace">
						<div class="col-md-6">
							<div class="formDetails">
								<h2 style="color:#0061cd; font-weight:bold;"><i class="fas fa-edit"></i> Form</h2>
								
								<form action="Contacts.php" method="GET">
									<div class="formout">
										<input type="text" required name="name" placeholder="Enter Your Name : " class="ip">
										<input type="text" required name="mob" placeholder="Enter Your Phone Number : " class="ip">
										<input type="text" required name="email" placeholder="Enter Your Email Address : " class="ip">
										<input type="text" required name="adds" placeholder="Enter Your Address : " class="ip">
										<textarea rows="5" required name="msg" cols="50" class="ip" placeholder="Enter Your Message"></textarea>
										
										<input type="submit" name="submit" class="subbtn" value="Submit" >
									</div>
								</form>
								
                                <?php
                                	if(isset($_GET['submit']))
                                	{
                                		$uname=$_GET['name'];
                                		$umob=$_GET['mob'];
                                		$uemail=$_GET['email'];
                                		$uaddress= $_GET['adds'];
                                		$umsg=$_GET['msg'];
                                		
                                		if($uname!=""&&$umob!=""&&$uemail=""&&$uaddress!=""&&$umsg!="")
                                		{
                                			$sql="INSERT INTO contactlist(NAME,PHONE,EMAIL,ADDRESS,MESSAAGE)VALUES('$uname','$umob','$uemail','$uaddress','$umsg')";
                                			
                                			if($conf->Query($sql))
                                			{
                                				echo "Processing Successfully";
                                			}
                                			else
                                			{
                                				echo "Processing Not Successfully";
                                			}
                                		}
                                		else
                                		{
                                			echo "Pls Fill All Details";
                                		}
                                	}
                               ?>
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="conDetails">
								<h2 style="color:#0061cd; font-weight:bold;"><i class="fas fa-address-book"></i> Contacts</h2>
								<h4 style="border:none;"><b><i class="fas fa-phone"></i> Phone No : +919629904769</b></h4>
								<h4 style="border:none;"><b><i class="fas fa-envelope"></i> Email : mssoft1650@gmail.com</b></h4>
								<h4 style="border:none;"><b><i class="fab fa-whatsapp"></i> WhatsApp : +919629904769</b></h4>
								<h2 style="color:#0061cd; font-weight:bold;"><i class="fas fa-map-marker-alt"></i> Address</h2>
								<h4 style="border:none;"><b>MSSoft1650</b></h4>
								<p style="border:none;"><b>Melamuthudaiyanpatti</b></p>
								<p style="border:none;"><b>Vellanur(Post)</b></p>
								<p style="border:none;"><b>Pudukkottai(District)</b></p>
								<p style="border:none;"><b>pincode : 622501</b></p>
							</div>
						</div>
						
					</div>
					
					<div class="row">
						<div class="col-md-12">
							<div class="mapscon"><br>
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1670.3570988082492!2d78.78287200351046!3d10.449400300685614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3baa825b66603103%3A0x3dfd1ec614f8c933!2sMSSoft1650!5e1!3m2!1sen!2sin!4v1529427317299" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
							</div>
						</div>
					</div>
				</div>
			</div>
	
	<div class="container">
		<div class="aboutDiv">
			<div class="row">
				<div class="col-md-12">
					<h1><center>Our <span>Clients</span></center></h1>
					
					<div class="borderDiv"></div>
					<div class="rotateDiv"></div>
					
					<div class="descDivd">
						<div class="owl-carousel">
						  <div class="box"><img src="img/i1.png"></div>
						  <div class="box"><img src="img/i2.png"></div>
						  <div class="box"><img src="img/i3.png"></div>
						  <div class="box"><img src="img/i4.png"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="container">
		<div class="aboutDiv">
			<div class="row">
				<div class="col-md-12">
				
				</div>
			</div>
		</div>
	</div>
	
	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="follow">
						<h4>Follow Us</h4>
						
						<p class="fborder"><a href="https://www.facebook.com/mssoft1650"><i class="fas fa-arrow-alt-circle-right"></i> Facebook</a></p>
						<p class="fborder"><a href="https://www.twitter.com/mssoft1650"><i class="fas fa-arrow-alt-circle-right"></i> Twitter</a></p>
						<p class="fborder"><a href="https://www.instagram.com/javacse/"><i class="fas fa-arrow-alt-circle-right"></i> Instagram</a></p>
						<p class="fborder"><a href="https://www.instagram.com/javacse/"><i class="fas fa-arrow-alt-circle-right"></i> Google</a></p>
						<p class="fborder"><a href="https://www.youtube.com/channel/UCTyxvgSc9FAHP0zJCWmVKQA"><i class="fas fa-arrow-alt-circle-right"></i> Youtube</a></p>
					</div>
				</div>
				
				<div class="col-md-4">
					<div class="follow">
						<h4>Address</h4>
					</div>
					
					<p class="fborder"><b><i class="fas fa-arrow-alt-circle-right"></i> MSSoft1650</b></p>
					<P class="fborder"><b>Melamuthudaiyanpatti</b></P>
					<p class="fborder"><b>Vellanur (Post)</b></p>
					<p class="fborder"><b>Pudukkottai (Dt)</b></p>
					<p class="fborder"><b>Pincode : 622501</b></p>
				</div>
				
				<div class="col-md-4">
					<div class="follow">
						<h4>Facebook</h4>
						<iframe class="fbdiv" src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fmssoft1650&tabs&width=350&height=214&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=1639933419393186" width="350" height="214" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="subFooter">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<a href="https://www.mssweb.ml"><i class="fas fa-mouse-pointer"></i> MSSoft1650 Version : 3.0</a>
				</div>
				<div class="col-md-6">
					<a href="https://www.mssweb.ml"><i class="fas fa-code"></i> Designed And Developed By : MSSoft1650</a>
				</div>
				
				<div class="col-md-12 folDiv">
					<a href="https://www.facebook.com/javacseofficial" class="ffollow"><i class="fab fa-facebook-f"></i></a><a href="https://www.twitter.com/mssoft1650" class="ffollow"><i class="fab fa-twitter"></i></a><a href="https://www.instagram.com/javacse/" class="ffollow"><i class="fab fa-instagram"></i></a><a  class="ffollow" href="https://plus.google.com/101447433080714641119"><i class="fab fa-google-plus-g"></i></a>
				</div>
			</div>
		</div> 
	</div>
</div>	

	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="js/menuScript.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/clients.js"></script>
	<script src="js/bootstrap.min.js"></script>

	<script>
	/*$(document).ready(function(){
		$(".mobMenu").click(function(){
			$("#sideMenu").fadeIn();
			$("#sideMenu").fadeIn("slow");
			$("#sideMenu").fadeIn(3000);
		});
		$(".closeBtn").click(function(){
			$("#sideMenu").fadeOut();
			$("#sideMenu").fadeOut("slow");
			$("#sideMenu").fadeOut(3000);
		});
	});*/
		function openSideMenu(){
			document.getElementById('sideMenu').style.width = '100%';
			document.getElementById('main').style.display = '';
		}
		function closeSideMenu(){
			document.getElementById('sideMenu').style.width = '0';
			document.getElementById('main').style.marginRight = '0';
		}
	</script>
	<!---Whatsapp Widget--->
<!-- WhatsHelp.io widget -->
<script type="text/javascript">
(function () {
var options = {
whatsapp: "+919629904769", // WhatsApp number
call_to_action: "Message us", // Call to action
position: "right", // Position may be 'right' or 'left'
};
var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
})();
</script>
<!-- /WhatsHelp.io widget --> 
</body>
</html>