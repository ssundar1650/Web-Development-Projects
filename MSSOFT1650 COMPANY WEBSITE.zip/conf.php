<?php
	$conf = new MySqli("ftp.mssweb.ml","msswebml","sitsoft1650admin","msswebml_contacts");
	
	if($conf->connect_error)
	{
		echo $conf->connect_error;
	}
?>