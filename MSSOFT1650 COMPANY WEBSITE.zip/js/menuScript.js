$(document).ready(function() {
			$(".mobMenu").click(function(){
				$(".menuDiv>ul>li").toggle(3000);
			});
});

