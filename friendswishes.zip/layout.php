<?php
	include "conf.php";
	session_start();
	
	unset($_SESSION["ID"]);
	unset($_SESSION["NAME"]);
	session_destroy();
	
	echo "<script>window.open('index.php','_self');</script>";
?>