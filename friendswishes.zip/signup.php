<?php
	include "conf.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Friendswishes - Sign Up</title>
	<meta charset='utf-8'/>
	<meta content='IE=edge' http-equiv='X-UA-Compatible'/>
	<meta name="description" content="MSSoft1650 | No1 Software And Website & Logo Designing And Developing Company In Pudukkottai,Tamil Ndu,India">
	<meta name="keywords" content="MSSoft1650,mssoft1650,mssweb,software company,web development company,logo designing,javacse,web design,seo">
	<meta name="author" content="MSSoft1650">
	<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
	<link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
	<style>
		.mainDiv{
			border-radius:20px;
			width:250px;
			padding:20px;
			background-color:black;
			margin:10px auto;
			-webkit-box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
			-moz-box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
			box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
		}
		.ipbox{
			background-color:black;
			border-radius:20px;
			width:90.5%;
			padding:10px;
			margin-bottom:10px;
		}
		.ipbtn{
			border-radius:20px;
			padding:10px;
			width:100%;
			background-color:#f1c40f!important;
			border:none;
			color:black;
			font-weight:bold;
		}
		input[type=text]{
			background-color:black;
			color:#f1c40f!important;
			text-align:center;
			font-weight:bold;
		}
		.same{
			text-align:center;
			color:#f1c40f!important;
			font-family: 'Yellowtail', cursive;
		}
	</style>
</head>
<body>
	<div class="mainDiv">
		<form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="POST">
		<h1 class="same"><center><b>Friendswishes</b></center></h1>
		<h3 class="same"><center><b><i class="fas fa-user-plus"></i> Signup Page</b></center></h3>
			<input type="text" required placeholder="Username : " name="uname" class="ipbox" />
			<input type="text" required placeholder="Password : " name="upass" class="ipbox" />
			<input type="text" required placeholder="Email : " name="umail" class="ipbox" />
			<input type="text" required placeholder="Phone Number : " name="uphone" class="ipbox" />
			<input type="submit" class="ipbtn" value="Im Join" name="submit" />
		</form>
		
		<?php
			if(isset($_POST["submit"]))
			{
				$sql="INSERT INTO admins(NAME,PASSWORD,EMAIL,PHONE) VALUES('{$_POST["uname"]}','{$_POST["upass"]}','{$_POST["umail"]}','{$_POST["uphone"]}')";
				
				if($conf->query($sql))
				{
					echo "You Joined";
					echo "<script>window.open('fwadmin.php','_self');</script>";
				}
				else
				{
					echo "Sorry Sam Time Error";
				}
			}
		?>
	</div>
</body>
</html>