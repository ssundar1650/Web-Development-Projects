<?php
	include "conf.php";
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Welcome To Friendswishes</title>
		<meta charset='utf-8'/>
		<meta content='IE=edge' http-equiv='X-UA-Compatible'/>
		<meta name="description" content="MSSoft1650 | No1 Software And Website & Logo Designing And Developing Company In Pudukkottai,Tamil Ndu,India">
		<meta name="keywords" content="MSSoft1650,mssoft1650,mssweb,software company,web development company,logo designing,javacse,web design,seo">
		<meta name="author" content="MSSoft1650">
		<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
		<link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
	</head>
<body>
		<?php
			$sql="SELECT * FROM birthdaydetails";
			
			$result=$conf->query($sql);
			
			if($result->num_rows>0)
			{
				$row=$result->fetch_assoc();
				
			}
		?>
	<div class="mainDiv">
		<h1 class="mytitle">Wish You Happy<br><i class="fas fa-birthday-cake"></i> Birthday <i class="fas fa-birthday-cake"></i></h1>
		<div class="borderBox">
		</div>
		<div class="rotateBox">
		</div>
		<h2 class="wishName"><?php echo $row["NAME"]; ?></h3>
		<h3 class="mytitle">Wishes By :</h3>
		<h2 class="wishName"><?php echo $row["WISHESBY"]; ?></h2>
		
		<div class="gifImg"><center><img src="img/showcase.gif" width="250px" height="250px" alt="Friendswishes"/></center></div>
		
		<div class="visiterDiv">
			<h3 class="mytitle">You Wish To <br> <i class="red"><i class="fas fa-birthday-cake"></i> <?php echo $row["NAME"]; ?> <i class="fas fa-birthday-cake"></i></i> <br> Guy Birthday</h3>
		<form action="wishes.php" method="GET">	
			<center><input type="text" placeholder="Enter Your Name : " name="visiterName" class="visiterInput" /></center>
			<center><input type="submit" value="Submit" class="submitBtn" /></center>
		</form>	
		</div>
		
		<div class="upcoming">
		<h3 class="red"><i class="fas fa-birthday-cake"></i> Upcoming Birthday</h3>
			<marquee direction="up" behavior="">
				<ol align="" style="font-weight:bold !important; width:49%;">
					<li><?php echo $row["FNAME"]; ?></li>
					<li><?php echo $row["SNAME"]; ?></li>
					<li><?php echo $row["TNAME"]; ?></li>
				</ol>
			</marquee>
		</div>
		<div class="borderBox">
		</div>
		<div class="rotateBox">
		</div>
		<h6 class="fwversion"><b><center>FW Version 1.0</center></b></h6>
		<footer>
			<a href="https://www.facebook.com/javacseofficial"><center>Designed And Developed By :<br>MSSoft1650</center></a>
		</footer>
		
		

	</div>
</body>
</html>