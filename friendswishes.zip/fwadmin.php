<?php
	include "conf.php";
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Friendswishes - Login</title>
	<meta charset='utf-8'/>
	<meta content='IE=edge' http-equiv='X-UA-Compatible'/>
	<meta name="description" content="MSSoft1650 | No1 Software And Website & Logo Designing And Developing Company In Pudukkottai,Tamil Ndu,India">
	<meta name="keywords" content="MSSoft1650,mssoft1650,mssweb,software company,web development company,logo designing,javacse,web design,seo">
	<meta name="author" content="MSSoft1650">
	<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
	<link href="https://fonts.googleapis.com/css?family=Yellowtail" rel="stylesheet">
	<style>
		.mainDiv{
			border-radius:20px;
			width:250px;
			padding:20px;
			background-color:black;
			margin:10px auto;
			-webkit-box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
			-moz-box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
			box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
		}
		.ipbox{
			background-color:black;
			border-radius:20px;
			width:90.5%;
			padding:10px;
			margin-bottom:10px;
		}
		.ipbtn{
			border-radius:20px;
			padding:10px;
			width:100%;
			background-color:#f1c40f!important;
			border:none;
			color:black;
			font-weight:bold;
		}
		.same{
			text-align:center;
			color:#f1c40f!important;
			font-family: 'Yellowtail', cursive;
		}
		input[type=text]{
			background-color:black;
			color:#f1c40f!important;
			text-align:center;
			font-weight:bold;
		}
		.error{
			color:red;
			text-align:center;
			margin-top:20px;
		}
	</style>
</head>
<body>
	<div class="mainDiv">
		<h1 class="same"><center><b>Friendswishes</b></center></h1>
		<h3 class="same"><center><b><i class="fas fa-user-lock"></i> Login Page</b></center></h3>
		<form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
			<input required type="text" name="uname" placeholder="Username : " class="ipbox" />
			<input required type="text" name="upass" placeholder="Password : " class="ipbox" />
			<input type="submit" name="submit" value="Login" class="ipbtn" />
		</form>
		
		<?php
			if(isset($_POST["submit"]))
			{
				$sql="SELECT * FROM admins WHERE NAME='{$_POST["uname"]}' and PASSWORD='{$_POST["upass"]}'";
				$result=$conf->query($sql);
				
				if($result->num_rows>0)
				{
					$row=$result->fetch_assoc();
					$_SESSION["ID"]=$row["ID"];
					$_SESSION["NAME"]=$row["NAME"];
					echo "<script>window.open('cpanel.php','_self');</script>";
				}
				else
				{
					echo "<h5 class='error'>Username Or Password Error :(</h5>";
				}
			}
		?>
	</div>
</body>
</html>