<?php
	$conf=new mysqli("localhost","root","1650","friendswishes");
	
	if(!$conf)
	{
		echo "Not Connected :(";
	}
?>