<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION["ID"]))
	{
		echo "<script>window.open('fwadmin.php?mes=Pls Login First','_self');</script>";
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Friendswishes CPanel</title>
	<meta charset='utf-8'/>
	<meta content='IE=edge' http-equiv='X-UA-Compatible'/>
	<meta name="description" content="MSSoft1650 | No1 Software And Website & Logo Designing And Developing Company In Pudukkottai,Tamil Ndu,India">
	<meta name="keywords" content="MSSoft1650,mssoft1650,mssweb,software company,web development company,logo designing,javacse,web design,seo">
	<meta name="author" content="MSSoft1650">
	<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
	<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<style>
		.mainDiv{
			width:250px;
			padding:20px;
			margin:0px auto;
			border:1px solid black;
			background-color:black;
			border-radius:20px;
			-webkit-box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
			-moz-box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
			box-shadow: 0px 0px 55px -1px rgba(0,0,0,0.75);
		}
		.ipbox{
			width:91%;
			padding:10px;
			margin-bottom:5px;
			border-radius:20px;
		}
		.ipbtn{
			width:100%;
			padding:5px;
			margin-bottom:15px;
			border-radius:20px;
			background-color:#f1c40f;
			color:black;
			font-weight:bold;
		}
		footer a{
			margin-top:10px;
			color:#f1c40f;
			text-decoration:none;
			font-weight:bold;
		}
		.same{
			color:#f1c40f!important;;
		}
		.aname{
			color:white;
		}
		input[type=text]{
			background-color:black;
			border-color:#f1c40f;
			font-weight:bold;
			text-align:center;
			color:yellow;
		}
		input[type=text]:active{
			border-radius:20px !important;
		}
		.aname a{
			color:#f1c40f;
			text-decoration:none;
		}
	</style>
</head>
<body>
	<div class="mainDiv">
		<h1 class="same"><center>Welcome To Friendswishes</center></h1>
		<h3 class="same"><center>Admin Control Panel</center></h3>
		<h3 class="aname"><center><i class="fas fa-user"></i> Mr.<?php echo $_SESSION["NAME"]; ?></center></h3>
		<h5 class="aname"><a href="layout.php"><center><i class="fas fa-unlock"></i> Layout</center></a></h5>
		<form action="cpanel.php" method="POST">
			<input required type="text" placeholder="Enter Birthday Guy Name : " name="bname" class="ipbox">
			<input required type="text" placeholder="Enter Wishes Guy Name : " name="wname" class="ipbox">
			<input type="submit" name="submit" class="ipbtn">
		</form>
		
		<h3 class="aname"><center>Up Coming <i class="fas fa-birthday-cake"></i> Birthday<br>Guys Name</center></h3>
		<form action="cpanel.php" method="POST">
			<input required type="text" placeholder="Enter First Guy Name : " name="1name" class="ipbox">
			<input required type="text" placeholder="Enter Second Guy Name : " name="2name" class="ipbox">
			<input required type="text" placeholder="Enter Third Guy Name : " name="3name" class="ipbox">
			<input type="submit" name="submit2" class="ipbtn">
		</form>
		
		<footer>
			<a href="https://www.facebook.com/javacseofficial"><center>Designed And Developed By :<br>MSSoft1650</center></a>
		</footer>
	</div>	
	<?php
		if(isset($_POST["submit"]))
		{
			$sql="UPDATE birthdaydetails SET NAME='{$_POST["bname"]}', WISHESBY='{$_POST["wname"]}' WHERE ID='1' ";
			
			$result=$conf->query($sql);
			
			echo "<script>
				$(document).ready(function(){
					alert('Submited Successfully :)');
				});
			</script>";
		}
		
		if(isset($_POST["submit2"]))
		{
			$sql2="UPDATE birthdaydetails SET FNAME='{$_POST["1name"]}', SNAME='{$_POST["2name"]}', TNAME='{$_POST["3name"]}' WHERE ID='1'";
			
			$result2=$conf->query($sql2);
			
			echo "<script>
				$(document).ready(function(){
					alert('Upcoming Birthday Guys List Submited Successfully :)');
				});
			</script>";
		}
	?>
</body>
</html>